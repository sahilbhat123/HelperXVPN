#!/bin/bash
echo "============================="
echo "     HELPERXVPN AIO MENU     "
echo "============================="
echo " 1. SSH Menu"
echo " 2. VMess Menu"
echo " 3. Trojan Menu"
echo " 4. Shadowsocks Menu"
echo " 5. System Settings"
echo " x. Exit"
echo "============================="
read -p "Select Option: " opt
case $opt in
  1) echo "SSH Menu here" ;;
  2) echo "VMess Menu here" ;;
  3) echo "Trojan Menu here" ;;
  4) echo "Shadowsocks Menu here" ;;
  5) echo "Settings here" ;;
  x) exit ;;
  *) echo "Invalid Option";;
esac

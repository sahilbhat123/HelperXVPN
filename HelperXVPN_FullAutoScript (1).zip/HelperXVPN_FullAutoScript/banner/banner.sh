#!/bin/bash
echo 'Welcome to HelperXVPN [By HELPER]'
#!/bin/bash
echo 'Installing gRPC for XRAY... [By HELPER]'
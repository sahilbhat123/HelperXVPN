#!/bin/bash
echo 'Setting up OpenVPN... [By HELPER]'
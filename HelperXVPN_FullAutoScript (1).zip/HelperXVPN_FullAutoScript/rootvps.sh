#!/bin/bash
echo 'Configuring root VPS access [By HELPER]'
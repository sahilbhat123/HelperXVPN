#!/bin/bash
echo 'Running main setup [By HELPER]'
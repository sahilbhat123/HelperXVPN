#!/bin/bash
echo 'Installing SSH over WebSocket... [By HELPER]'
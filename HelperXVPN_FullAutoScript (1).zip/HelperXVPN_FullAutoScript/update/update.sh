#!/bin/bash
echo 'Updating HelperXVPN Scripts... [By HELPER]'
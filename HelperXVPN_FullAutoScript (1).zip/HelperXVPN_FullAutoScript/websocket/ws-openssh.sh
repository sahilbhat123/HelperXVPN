#!/bin/bash
echo 'Setting up WebSocket OpenSSH... [By HELPER]'
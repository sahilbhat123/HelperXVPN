#!/bin/bash
echo 'Installing XRAY... [By HELPER]'